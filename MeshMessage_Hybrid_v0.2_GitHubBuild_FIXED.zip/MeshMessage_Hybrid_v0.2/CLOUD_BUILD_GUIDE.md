# Cloud APK build from Android phone

1. Upload this project ZIP itself to the root of your GitHub repository with the exact filename:
   `MeshMessage_Hybrid_v0.2_GitHubBuild.zip`
2. In GitHub choose Add file -> Create new file.
3. Enter path `.github/workflows/build-android-apk.yml`.
4. Paste the workflow from `workflow-build-apk.yml` (the separate file supplied with this package) and commit to `main`.
5. Open Actions -> Build MeshMessage APK -> Run workflow.
6. When it completes, open the run and download `meshmessage-android-apk` from Artifacts.
7. Extract the artifact ZIP and install `app-release.apk`.

The build may expose further compile issues; share the failed Actions log if it does.
The generated APK is still an early prototype: phone-to-phone BLE is plaintext,
LoRa transmission is disabled pending Indian radio compliance confirmation,
and encryption/multi-hop are not yet implemented.
